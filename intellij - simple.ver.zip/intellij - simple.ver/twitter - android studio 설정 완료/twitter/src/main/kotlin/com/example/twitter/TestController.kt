//package com.example.twitter
//
//import org.springframework.context.annotation.Bean
//import org.springframework.context.annotation.Configuration
//import org.springframework.web.cors.CorsConfiguration
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource
//import org.springframework.web.filter.CorsFilter
//
//@RestController
//@RequestMapping("/api")
//class TestController {
//    @GetMapping("/hello")
//    fun getHello(): ResponseEntity<String> {
//        return ResponseEntity.ok("Hello from Spring Boot!")
//    }
//}