package com.example.twitter;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/front")
public class FrontendController {
    /// 사용자명 입력받는 폼 실행 - 프론트엔드 파일로 바꾸기
    @GetMapping("/")
    public String showForm() {
        /// index.html 실행
        return "index";
    }

/// index.xml을 실행하고 싶다면 - 코드 테스트 필요
//    @GetMapping("/")
//    public String showForm() {
//        return "index.xml";
//    }
}
