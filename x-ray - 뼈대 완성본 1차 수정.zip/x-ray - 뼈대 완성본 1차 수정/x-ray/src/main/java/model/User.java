package model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// model: 컨트롤러와 뷰 사이의 데이터 전달 역할
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;  // 트위터 사용자 이름
    private String twitterId; // 트위터 사용자 ID
    private String profileUrl; // 사용자 프로필 URL
    private boolean isBot;     // AI 봇 여부
    private boolean isImpersonator; // 사칭 여부

    public User(String username, String twitterId, String profileUrl) {
        this.username = username;
        this.twitterId = twitterId;
        this.profileUrl = profileUrl;
    }

    public User() {

    }

    // getter, setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTwitterId() {
        return twitterId;
    }

    public void setTwitterId(String twitterId) {
        this.twitterId = twitterId;
    }

    public String getProfileUrl() {
        return profileUrl;
    }

    // AI 봇인지
    public boolean isBot() {
        return isBot;
    }

    public void setBot(boolean isBot) {
        this.isBot = isBot;
    }

    // 사칭인지
    public boolean isImpersonator() {
        return isImpersonator;
    }

    public void setImpersonator(boolean isImpersonator) {
        this.isImpersonator = isImpersonator;
    }
}
