package detetox.x_ray.controller;

import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import detetox.x_ray.model.Probability;
import detetox.x_ray.model.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai")
public class AIController {
    private final Map<String, User> userMap = new HashMap<>();
    ///클래스로 합쳐야하나?

    @PostMapping("/id")
    @Operation(
            summary = "조회한 ID 저장",
            description = "ID와 확률 리스트를 받아서 저장하는 API",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "조회한 id 값을 String 변수로 전달받기",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(
                                    type="String",
                                    description = "조회한 사용자 ID (String 타입)",
                                    example = "detetox123"
                            )
                    )
            ),
            responses = {
                    @ApiResponse(responseCode = "200", description = "성공적으로 확률 리스트 저장",
                            content = @Content(schema = @Schema(implementation = User.class))),
                    @ApiResponse(responseCode = "400", description = "잘못된 요청")
            }
    )
    public ResponseEntity<Probability> getFromModel(@RequestBody String id) {
        ///임시값 value
        Double a=0.3;
        Double b=0.3;
        List<Double> value = Arrays.asList(a, b);

        User user = new User();
        user.setTwitterId(id);
        userMap.put(id, user);
        Probability prob = new Probability(user);
        prob.setProbabilities(value);
        return ResponseEntity.ok(prob);
    }
}
