//package controller;
////for application.properties 파일의 값을 클래스에 주입하는 @Value 어노테이션 사용
//import org.springframework.beans.factory.annotation.Value;
////for API 데이터 요청을 처리하는 @GetMapping 어노테이션 사용
//import org.springframework.web.bind.annotation.GetMapping;
////for HTTP 요청 처리 및 응답 반환
//import org.springframework.web.bind.annotation.RestController;
//
//
//
//@RestController
//public class TwitterController {
//    //application.properties 파일에서 값 가져오기
//    @Value("${twitter.bearer-token}")
//    private String bearerToken;
//
//
////    @Value("${database.url}")
////    private String databaseUrl;
////
////    // /token 경로로 get 요청이 들어오면 getBearerToken 메소드 실행
////    @GetMapping("/token")
////    public String getBearerToken() {
////        return bearerToken;
////
////    }
////
////    @GetMapping("/db-url")
////    public String getDatabaseUrl() {
////        return databaseUrl;
////    }
//}
