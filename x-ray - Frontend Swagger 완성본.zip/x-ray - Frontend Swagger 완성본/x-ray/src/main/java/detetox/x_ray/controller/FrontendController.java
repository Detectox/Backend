package detetox.x_ray.controller;

//import api.CommonResponse;
import detetox.x_ray.model.Probability;
import detetox.x_ray.model.Test;
import detetox.x_ray.model.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.hibernate.annotations.Array;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


//RestController는 REST API를 생성할 때 사용하는 어노테이션
//RequestMapping("/api")는 모든 요청 url이 /api로 시작하도록 설정함으로써 엔드포인트 관리 편해짐


@RestController
@RequestMapping("/front")
public class FrontendController {
    private final Map<String, User> userMap = new HashMap<>();

    /// 프론트로부터 id 입력받아 저장하기
    //클라이언트가 /id 경로로 POST 요청 시 실행
    //@RequestBody : 클라이언트가 요청한 JSON 데이터를 메서드의 매개변수로 변환하는 어노테이션
    //ResponseEntity : Spring에서 HTTP 응답을 제어하는 객체
    @PostMapping("/id")
    @Operation(
            summary = "조회할 ID 저장",
            description = "전달받은 ID로 새로운 사용자 객체 생성 및 해당 사용자 객체를 반환하는 API",
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "조회할 id 값을 String 변수로 전달받기",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(
                                    type="String",
                                    description = "조회할 사용자 ID (String 타입)",
                                    example = "detetox123"
                            )
                    )
            ),
            responses = {
                    @ApiResponse(responseCode = "200", description = "성공적으로 생성된 사용자 객체 반환",
                            content = @Content(schema = @Schema(implementation = User.class))),
                    @ApiResponse(responseCode = "400", description = "잘못된 요청")
            }
    )
    public ResponseEntity<User> searchById(@RequestBody String input) {
        User user = new User();
        user.setTwitterId(input);
        userMap.put(input, user);
        return ResponseEntity.ok(user);
    }

    /// 프론트로 확률 배열 넘기기
    //클라이언트가 /api/probabilities 경로로 GET 요청 시 실행
    //@PathVariable : url에서 일부 값 직접 가져오기
    @GetMapping("/probabilities/{id}")
    @Operation(
            summary = "ID에 대한 확률 리스트 반환",
            description = "ID를 이용해 해당 계정 위험도에 대한 확률 리스트를 반환하는 API",
            parameters = @Parameter(
                    name = "id",
                    description = "조회한 ID",
                    required = true,
                    example = "detetox123"
            ),
            responses = {
                    @ApiResponse(responseCode = "200", description = "성공적으로 확률 리스트 반환"
//                        , content = @Content(mediaType = "application/json",
//                            schema = @Schema(
//                                    type = "array",
//                                    description = "계정 위험도 확률값 리스트",
//                                    example = "[0.1, 0.5, 0.9]"
//                                    )
//                        )
                    ),
                    @ApiResponse(responseCode = "400", description = "잘못된 요청")
            }
    )
    public ResponseEntity<List<Double>> sendProbabilities(@PathVariable String id) {

        User user = userMap.get(id);
        if (user == null) {
            return  ResponseEntity.badRequest().body(Collections.emptyList());
        }
        Probability prob = new Probability(user);

        /// 예제코드
        prob.setProbabilities(List.of(0.1, 0.5, 0.9));

        return ResponseEntity.ok(prob.getProbabilities());

    }



}
