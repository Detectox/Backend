package detetox.x_ray.model;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;


import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Schema(description = "Probability 엔티티; 계정 위험도 확률 값을 포함하는 클래스")
public class Probability {
    @Id
    @Schema(description = "User 클래스로부터 받아온 Twitter ID", required = true, example = "detetox123")
    private String prob_id;

    @ElementCollection
    @CollectionTable(
            name="probabilities",
            joinColumns = @JoinColumn(name="probability_id")
    )
    @Column(name="value")
    @Schema(description = "계정 위험도 확률 값 리스트")
    private List<Double> probabilities = new ArrayList<>();

    public Probability(User user) {
        this.prob_id = user.getTwitterId();
    }

    public List<Double> getProbabilities() {
        return probabilities;
    }
    public void setProbabilities(List<Double> probabilities) {
        this.probabilities = probabilities;
    }

    public String getProbId(){
        return prob_id;
    }

    public void setProbId(String id){
        this.prob_id = id;
    }



}
