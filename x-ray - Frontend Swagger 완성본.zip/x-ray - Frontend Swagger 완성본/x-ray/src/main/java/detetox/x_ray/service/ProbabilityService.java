//package detetox.x_ray.service;
//
//import detetox.x_ray.model.Probability;
//import detetox.x_ray.model.User;
//import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.Parameter;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//
//import java.util.List;
//
//
//public class ProbabilityService {
//    @Operation(
//            summary = "test용",
//            description = "User 객체를 기반으로 새로운 Probability 객체를 생성하여 반환",
//            parameters = @Parameter(
//                    name = "user",
//                    description = "사용자 정보를 담고 있는 User 객체",
//                    required = true,
//                    schema = @Schema(implementation = User.class)
//            ),
//            responses = {
//                    @ApiResponse(
//                            responseCode = "200",
//                            description = "성공적으로 Probability 객체가 생성되어 반환됨",
//                            content = @Content(
//                                    schema = @Schema(implementation = Probability.class)
//                            )
//                    ),
//                    @ApiResponse(
//                            responseCode = "400",
//                            description = "잘못된 요청"
//                    )
//            }
//    )
//    public Probability createProbability(User user) {
//        Probability probability = new Probability(user);
//
//        return probability;
//    }
//
//}
