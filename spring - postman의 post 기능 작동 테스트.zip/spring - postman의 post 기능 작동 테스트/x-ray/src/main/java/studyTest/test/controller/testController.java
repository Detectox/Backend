package studyTest.test.controller;

import org.springframework.web.bind.annotation.*;
import studyTest.test.user.Param;

@RestController
public class testController {

    @PostMapping("/test")
    public Param post(@RequestBody Param param) {
        Param param1 = new Param();
        param1.setName(param.getName());
        return param1;
    }
}