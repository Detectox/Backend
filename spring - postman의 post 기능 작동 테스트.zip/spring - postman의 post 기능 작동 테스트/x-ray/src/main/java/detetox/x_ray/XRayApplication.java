//package detetox.x_ray;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class XRayApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(XRayApplication.class, args);
//	}
//
//}
