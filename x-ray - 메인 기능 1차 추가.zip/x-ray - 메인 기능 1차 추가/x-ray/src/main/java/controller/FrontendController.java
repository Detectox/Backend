package controller;

import model.Probability;
import model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


//RestController는 REST API를 생성할 때 사용하는 어노테이션
//RequestMapping("/api")는 모든 요청 url이 /api로 시작하도록 설정함으로써 엔드포인트 관리 편해짐


@RestController
@RequestMapping("/api")
public class FrontendController {
    private final Map<Long, User> userMap = new HashMap<>();

    /// 프론트로부터 id 입력받아 저장하기
    //클라이언트가 /id 경로로 POST 요청 시 실행
    //@RequestBody : 클라이언트가 요청한 JSON 데이터를 메서드의 매개변수로 변환하는 어노테이션
    //ResponseEntity : Spring에서 HTTP 응답을 제어하는 객체
    @PostMapping("/id")
    public ResponseEntity<Long> searchById(@RequestBody Long input) {
        User user = new User();
        user.setId(input);
        userMap.put(input, user);
        return ResponseEntity.ok(user.getId());
    }

    /// 프론트로 확률 배열 넘기기
    //클라이언트가 /api/probabilities 경로로 GET 요청 시 실행
    //@PathVariable : url에서 일부 값 직접 가져오기
    @GetMapping("/probabilities/{id}")
    public ResponseEntity<List<Double>> sendProbabilities(@PathVariable Long id) {
        User user = userMap.get(id);
        if (user == null) {
            return  ResponseEntity.badRequest().body(null);
        }

        Probability prob = new Probability();
        List<Double> numbers = prob.getProbabilities();

        return ResponseEntity.ok(numbers);

    }

}
