package repository;

import model.Probability;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProbabilityRepository extends JpaRepository<Probability, Integer> {
}
