package service;

public class ProbabilityService {
}
