package model;


import java.util.List;

public class Probability {

    private List<Double> probabilities;
    public List<Double> getProbabilities() {
        return probabilities;
    }
    public void setProbabilities(List<Double> probabilities) {
        this.probabilities = probabilities;
    }

}
