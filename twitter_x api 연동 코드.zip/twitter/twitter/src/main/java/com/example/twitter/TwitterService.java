package com.example.twitter;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

@Service
public class TwitterService {
    private final String BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAACZJyQEAAAAACvB16Htw7xEe8ua%2Ft9kzOTLndj4%3DJDY4rtSBszpeXMfAkTHHwJHFXYwl8BoKU38LQqHRZjDIWATAZf";
    private final String BASE_URL = "https://api.twitter.com/2/users/by/username/";

    public String getUserInfo(String username) {
        String url = BASE_URL + username + "?user.fields=created_at,description,public_metrics";

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + BEARER_TOKEN);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

        return response.getBody();
    }
}
