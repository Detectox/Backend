package com.example.twitter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/twitter")
public class TwitterController {
    private final TwitterService twitterService;

    public TwitterController(TwitterService twitterService) {
        this.twitterService = twitterService;
    }

    // 사용자명 입력받는 폼
    @GetMapping("/")
    public String showForm() {
        return "index";
    }

    @GetMapping(value = "/user", produces = MediaType.APPLICATION_XML_VALUE)
    @ResponseBody
    public ResponseEntity<String> getUser(@RequestParam("username") String username) throws Exception {
        String userInfoJson = twitterService.getUserInfo(username);

        // JSON을 XML로 변환
        ObjectMapper jsonMapper = new ObjectMapper();
        XmlMapper xmlMapper = new XmlMapper();
        Object userObject = jsonMapper.readValue(userInfoJson, Object.class);
        String userInfoXml = xmlMapper.writeValueAsString(userObject);

        return ResponseEntity.ok(userInfoXml);
    }


}
